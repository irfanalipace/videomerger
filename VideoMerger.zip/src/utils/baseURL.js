export const BASE_URL = "https://hlpbackend.waveenviroservices.com/api/";
export const AUTH_LOGIN = "auth/login/admin";
export const AUTH_LOGOUT = "auth/logout";
