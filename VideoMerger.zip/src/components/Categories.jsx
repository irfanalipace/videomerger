import React from 'react'

const Categories = () => {
  return (
    <div className='w-100 bg-[#10102EBF] border-2 border-primary rounded-2xl'>
        <div className='flex gap-2'>
<p className='text-primary text-md font-bold border-r-2 border-primary px-3 py-1'>Category</p>
<p className='text-primary text-md border-r-2 font-bold border-primary px-3 py-1'>Category</p>
<p className='text-primary text-md border-r-2 font-bold border-primary px-3 py-1'>Category</p>
<p className='text-primary text-md pr-3 font-bold border-primary py-1' >Category</p>
        </div>
        <div className='border-t-2 border-primary flex items-center justify-center flex-wrap gap-4 py-3 px-1'>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
            <p className='py-3 px-10 bg-primary rounded-full'></p>
           
        </div>
    </div>
  )
}

export default Categories