import Logo from './wallartlogo.png';
import VideoDisplay from './Video Display.png';
import AboutImage from './About Window.png';

export { Logo, VideoDisplay ,AboutImage};
